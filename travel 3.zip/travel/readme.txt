airport.php   根据你输入的地点(英文或者拼音),获取航班信息,主要是获取AirportCode(机场代码)
countryData.js 存取的对应的城市的机场代码,作用是根据城市名获得相应的AirportCode(机场代码)
getPrice.php   根据你的起始地点以及时间信息来获取机票价格
travel.php     新加了一个字段countryName,因为起点是要你自己输入的,终点是根据套餐信息来获得的,所以我将每个套餐的所在城市爬取下来了。(这边你可以根据城市名在countryData.js中找出相应的code)

链接:

查机票代码网址： http://www.ting.com.tw/agent/air-code.htm
WV网址:        https://www.dreamtrips.com
账户信息:(可以登陆上去看下具体它怎么调用)

徐凤宝][表情]
成为WorldVentures公司的一员，请牢记以下信息:
[表情][表情][表情][表情][表情][表情][表情][表情][表情]
会员后台网址:
backoffice.worldventures.biz
会员账号：67646925
登录密码：ABC123456abc
电子钱包网址:
worldventures.globalewallet.com
钱包帐户: 67646925
登录密码: 同上
交易密码：自己设置
订旅游套餐网站:
www.dreamtrips.com
订酒店机票网站:
www.dreamtripslife.com
会员帐号与密码同上
